package com.example.task2;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    // declarations for finals of class
    private final String ZERO="0";
    private final String ONE="1";
    private final String TWO="2";
    private final String THREE="3";
    private final String FOUR="4";
    private final String FIVE="5";
    private final String SIX="6";
    private final String SEVEN="7";
    private final String EIGHT="8";
    private final String NINE="9";
    private final String ADD="+";
    private final String SUB="-";
    private final String EQUALS="=";
    private final String EMPTY="";
    private final String MUL="*";
    private final String DIV="/";
    // declarations for class variables
    private double result=0;
    private int i=0,j=0;
    private ArrayList<String> actions=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void activateCalculator(View view){
        TextView showScreen=findViewById(R.id.showScreen);// holds the screen
        //holds the three buttons
        Button add=findViewById(R.id.add);
        Button sub=findViewById(R.id.sub);
        Button equals=findViewById(R.id.equals);
        Button mul=findViewById(R.id.mul);
        Button div=findViewById(R.id.div);
        Button dot=findViewById(R.id.dot);
        String [] numbers;
        add.setEnabled(false);
        equals.setEnabled(false);
        mul.setEnabled(false);
        div.setEnabled(false);
        dot.setEnabled(false);
        switch (view.getId()){//each case is a different button
            case R.id.zero:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(ZERO);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.one:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(ONE);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.two:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(TWO);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.three:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(THREE);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.four:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(FOUR);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.five:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(FIVE);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.six:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(SIX);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.seven:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(SEVEN);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.eight:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(EIGHT);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.nine:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                showScreen.append(NINE);
                // these buttons are currently enabled
                add.setEnabled(true);
                sub.setEnabled(true);
                equals.setEnabled(true);
                mul.setEnabled(true);
                div.setEnabled(true);
                dot.setEnabled(true);
                break;
            case R.id.dot:
                if(showScreen.getText().toString()!=EMPTY) {// if the screen is not empty
                    showScreen.append(".");
                    // these buttons are currently disabled
                    add.setEnabled(false);
                    sub.setEnabled(false);
                    equals.setEnabled(false);
                    mul.setEnabled(false);
                    div.setEnabled(false);
                    dot.setEnabled(false);
                }
                break;
            case R.id.add:
                if(showScreen.getText().toString()!=EMPTY) {// if the screen is not empty
                    actions.add(ADD);// add to the actions array the action ADD
                    showScreen.append(ADD);
                    // these buttons are currently disabled
                    add.setEnabled(false);
                    sub.setEnabled(false);
                    equals.setEnabled(false);
                    mul.setEnabled(false);
                    dot.setEnabled(false);
                }
               else {
                    add.setEnabled(false);
                    equals.setEnabled(false);
                }
                break;
            case R.id.sub:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                actions.add(SUB);// add to the actions array the action SUB
                showScreen.append(SUB);
                // these buttons are currently disabled
                add.setEnabled(false);
                sub.setEnabled(false);
                equals.setEnabled(false);
                mul.setEnabled(false);
                dot.setEnabled(false);
                break;
            case R.id.mul:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                actions.add(MUL);
                showScreen.append(MUL);
                add.setEnabled(false);
                equals.setEnabled(false);
                mul.setEnabled(false);
                dot.setEnabled(false);
                break;
            case R.id.div:
                if(showScreen.getText().toString().contains(EQUALS)) {// check if we already calculate something and clear the screen if so
                    showScreen.setText(EMPTY);
                    actions.clear();// clear also the array actions
                }
                actions.add(DIV);
                showScreen.append(DIV);
                add.setEnabled(false);
                equals.setEnabled(false);
                mul.setEnabled(false);
                dot.setEnabled(false);
                break;
            case R.id.equals:
                if(showScreen.getText().toString()!=EMPTY){//if the screen is not empty
                    numbers =showScreen.getText().toString().split("[/*+-]");// split the screen to array of numbers
                    //the condition did'nt work when i compared the char to SUB even when I converted the char, that's why I used the char '-'
                    if (showScreen.getText().toString().charAt(0)=='-') {//if the screen starts with -
                        numbers = showScreen.getText().toString().substring(1).split("[/*+-]");// split the same but without the '-' at first
                    }
                    result=0;
                    i=0;
                    j=0;
                    while (i<numbers.length){// go through the numbers array
                        if(i==0) {//if its the first number
                            result = Double.parseDouble(numbers[i]);// put the number in result
                            ////the condition did'nt work when i compared the char to SUB even when I converted the char, that's why I used the char '-'
                            if (showScreen.getText().toString().charAt(0)=='-')//if the screen starts with -
                            {
                                result*=(-1);// change the first number to negative
                                actions.remove(0);// and remove the first SUB from the array actions
                            }
                        }
                        else if(actions.get(j)==ADD) {// if the action is now ADD
                            result += Double.parseDouble(numbers[i]);// add the numbers
                            j++;
                        }
                        else if(actions.get(j)==SUB) {// if the action is now SUB
                            result -= Double.parseDouble(numbers[i]);// sub the numbers
                            j++;
                        }
                        else if (actions.get(j)==MUL){// if the action is now MUL
                            result *= Double.parseDouble(numbers[i]);// multiply the numbers
                            j++;
                        }
                        else if (actions.get(j)==DIV){// if the action is now MUL
                            result /= Double.parseDouble(numbers[i]);// divide the numbers
                            j++;
                        }
                        i++;
                    }
                    showScreen.append(EQUALS);
                    showScreen.append(result+"");//show the result
                }
                else// if the screen is empty we can't use this buttons
                {
                    add.setEnabled(false);
                    equals.setEnabled(false);
                    mul.setEnabled(false);
                    div.setEnabled(false);
                    dot.setEnabled(false);
                }
                break;
            case R.id.cleanScreen:
                showScreen.setText(EMPTY);// clear the screen
                actions.clear();// clear the actions array
                break;
        }
    }

}
